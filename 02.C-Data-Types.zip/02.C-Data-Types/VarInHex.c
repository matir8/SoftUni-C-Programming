#include <stdio.h>

/*03.Declare an integer variable and assign it with the value 254 in hexadecimal format (0x##). Use a calculator online to
find its hexadecimal representation. Print the variable and ensure that the result is "254".*/


int main()
{
    int a = 254;
    printf("%d in hex format is 0x%x\n", a, a);
    
	return 0;
}
