#include <stdio.h>
#include <stdbool.h>

/*04.Declare a variable called isFemale and assign an appropriate value corresponding to your gender. Print it on the
console.*/


int main()
{
    bool isFamele = false;
    printf("%s\n", isFamele ? "true" : "false");
    
	return 0;
}

