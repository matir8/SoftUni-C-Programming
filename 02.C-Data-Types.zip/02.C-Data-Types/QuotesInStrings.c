#include <stdio.h>

/*06.Declare a string variable and assign to it the following value:
The "use" of quotations causes difficulties. \n, \t and \ are also special
characters.).*/


int main()
{
    
    printf("Declare a string variable and assign to it the following value:The \"use\" of quotations causes difficulties. \\n, \\t and \\ are also special characters.\n");
    
	return 0;
}

