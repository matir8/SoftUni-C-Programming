#include <stdio.h>
#include <stdlib.h>

//03.Create, compile and run a "Hello, C" console application. 

int main() 
{
    printf("Hello, C! \n");
    return 0;
}


