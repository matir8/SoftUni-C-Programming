#include <stdio.h>
#include <stdlib.h>

//04.Modify the previous program to print your name.

int main() 
{
    
    char name[] = "Martin";
    printf("My name is %s.\n" , name);
    return 0;
}



