#include <stdio.h>
#include <stdlib.h>

//06.Create console application that prints your first and last name, 
//each at a separate line.

int main() 
{
    char firstName[] = "Martin";
    char lastName[] = "Markov";
    
    printf("%s\n%s\n", firstName, lastName);
    
    return 0;
}

